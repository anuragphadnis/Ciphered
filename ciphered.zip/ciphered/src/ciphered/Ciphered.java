/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ciphered;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author Windows
 */
public class Ciphered {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) throws IOException{
        // TODO code application logic here
        FileWriter fout=null;
        FileReader fin=null;
        try{
        fout =new FileWriter("sample.enc");
        fin= new FileReader("sample.txt");
        int c;
        while((c=fin.read())!=-1)
        {
            fout.write(c*47);
        }
        fin.close();
        fout.close();
        fin = new FileReader("sample.enc");
        fout=new FileWriter("sampletest.txt");
        while((c=fin.read())!=-1)
        {
            fout.write(c/47);
        }
        }
        finally
        {
            if(fout!=null)
                fout.close();
            if(fin!=null)
                fin.close();
        }
    }
    
}
